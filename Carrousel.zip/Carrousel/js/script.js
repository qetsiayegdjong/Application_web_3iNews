$(document).ready(function(){

	// Définir les options
	var vitesse = 500;  // vitesse fondu
	var detecteur = true; // slide automatique
	var detecteur_vitesse = 4000; // slide de vitesse automatique

	// Activer les classes définies

	$('.slide').first().addClass('active');

	// Cacher tous les slides
	$('.slide').hide();

	//Afficher le premier slide
	$('.active').show();

	//instruction sur le prochain slide
	$('#next').on('click',nextSlide);

	
	//instruction sur le slide précédent
	$('#prev').on('click',prevSlide);


	//Instruction pour le slide automatique
	if(detecteur == true){
		setInterval(nextSlide,detecteur_vitesse);
	}

	//Passer au prochain slide

		function nextSlide(){
			$('.active').removeClass('active').addClass('oldActive');
			if($('.oldActive').is(':last-child')){
				$('.slide').first().addClass('active');
			}else{
				$('.oldActive').next().addClass('active');
			}

			$('.oldActive').removeClass('oldActive');
			$('.slide').fadeOut(vitesse);
			$('.active').fadeIn(vitesse);
		}

	//Passer à l'ancien slide

		function prevSlide(){
			$('.active').removeClass('active').addClass('oldActive');
			if($('.oldActive').is(':first-child')){
				$('.slide').last().addClass('active');
			}else{
				$('.oldActive').prev().addClass('active');
			}

			$('.oldActive').removeClass('oldActive');
			$('.slide').fadeOut(vitesse);
			$('.active').fadeIn(vitesse);
		}


});
