<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 19/10/16
 * Time: 09:59
 */
defined('SECURITE') or die('ACCES INTERDIT');
require_once 'utilisateur.php';