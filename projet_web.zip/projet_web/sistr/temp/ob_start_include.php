<?php
$a = 1;
echo "<br><b>Inclusion de ".basename(__FILE__).'</b><br><br>';



