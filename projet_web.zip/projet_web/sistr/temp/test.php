<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 19/10/16
 * Time: 09:08
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
    <body>
        <h1>
            Test.PHP
        </h1>
        <h2>Conteneu de $_GET</h2>
        <pre>
            <?php print_r($_GET);?>
        </pre>
        <h2>
            Contenu de $_POST
        </h2>
        <pre>
            <?php print_r($_POST);?>
        </pre>
    </body>
</html>
