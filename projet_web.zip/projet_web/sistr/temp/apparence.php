<?php
defined('SECURITE') or die('ACCES INTERDIT');
?>
<p style="border-top:1px solid gray;border-bottom:1px solid gray;margin:20px 0px;color:gray;">Un truc que le m&eacute;chant prof voulait absolument mettre &agrave; l'&eacute;cran<?php echo ' '.$heure;?></p>
