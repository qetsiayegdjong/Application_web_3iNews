<div>
    <h2>Vue 2</h2>
    <pre><?php print_r($_SESSION)?></pre>
</div>

