$( document ).ready(function() {

	$("#b1").hide();
 
    $( "#bouton" ).click(function( event ) {

    	var commande = "drbl-ocs";

    	var selected = [];
		$('#cb input:checked').each(function() {
		    selected.push($(this).attr('name'));
		});

		for(var i = 0 ; i < selected.length ; i++){
			commande += " " + selected[i];
		}


		//if($("input[type=radio][name=optp]:checked").length == 1){
			var p = $("input[type=radio][name=optp]:checked").attr('value');
			var compression = $("input[type=radio][name=compression]:checked").attr('value');
			var decoup = $("#decoup").val();
			var image_name = $("#image_name").val();
			var disk_name = $("#disk_name").val();
			$("#cmd").text(commande + ' -p ' + p + ' -' + compression + ' -i ' + decoup + ' -l fr-FR.UTF-8' + ' startdisk save ' + image_name + ' ' + disk_name);
		//}
        
        $("#cmd").html($("#cmd").html().replace(/\n/g,'<br/>'));
 
        event.preventDefault();
 
    });

    $(".help").click(function(e){
    	e.preventDefault();
    });

    $("#help1").click(function(e){
    	$("#b1").show(1000);
    });
 
});