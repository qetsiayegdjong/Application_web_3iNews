<html>
	<head>
		<title>PAM</title>
	</head>
	<body>
	<?php
		$error ="";
		pam_auth("administrateur","admin");
	?>
	</body>
</html>