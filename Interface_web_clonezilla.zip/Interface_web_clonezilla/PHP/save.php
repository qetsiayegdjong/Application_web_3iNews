<html>
<head>
	<title>Sauvegarde disque</title>
</head>
<body>
    <script src="jquery.js"></script>
    <script src="script.js"></script>
    <style>
    .bloc_aide{
    	background-color: yellow;
    	padding:5px;
    }
    </style>
	<table border="1">
	<tr>
	<td>
	<form method="post" action="test.php">
		<div>
			<div id="cb">
				<input type="checkbox" id="test1" name="-a" checked/> <label for="test">Test 1</label> <button class="help" id="help1">?</button><br />
				<input type="checkbox" id="test2" name="-b" /> <label for="test">Test 2</label> <button class="help" id="help2">?</button><br />
				<input type="checkbox" id="test3" name="-c" disabled/> <label for="test">Test 3</label> <button class="help" id="help3">?</button><br />
				<input type="checkbox" id="test4" name="-d" /> <label for="test">Test 4</label> <button class="help" id="help4">?</button><br />
				<input type="checkbox" id="test5" name="-e" /> <label for="test">Test 5</label> <button class="help" id="help5">?</button><br />
			</div>

			<input type="radio" id="poweroff" name="optp" value="poweroff" checked/> <label for="poweroff">poweroff</label> <input type="radio" id="reboot" name="optp" value="reboot"/> <label for="reboot">reboot</label> <input type="radio" id="choose" name="optp" value="choose"/> <label for="choose">choose</label> <input type="radio" id="true" name="optp" value="true"/> <label for="true">true</label><button class="help" id="help6">?</button> <br />

			<input type="radio" id="z1p" name="compression" value="z1p" checked/> <label for="z1p">z1p</label> <input type="radio" id="z1" name="compression" value="z1"/> <label for="z1">z1</label> <input type="radio" id="z2p" name="compression" value="z2p"/> <label for="z2p">z2p</label> <input type="radio" id="z2" name="compression" value="z2"/> <label for="z2">z2</label><button class="help" id="help6">?</button> <br />

			<label for="decoup">Taille découpage:</label><input type="number" name="decoup" id="decoup" value="1000000"/><br />

			<label for="image_name">Nom de l'image:</label><input type="text" name="image_name" id="image_name"/><br />

			<label for="disk_name">Nom de la partition:</label><input type="text" name="disk_name" id="disk_name" value="sda"/><br />
		</div>
		<button id="bouton">Générer commande</button>
	</form>
	<div id="cmd" style="background-color:black;width:1000px;color:lime;padding:10px;font-family:'Courier new'">

	</div>
	<button style="color:red">Executer la commande</button>
	</td>
	<td>
		<div class="bloc_aide" id="b1">
		Voici de l'aide pour l'option 1.
		</div>
	</td>
	</tr>
	</table>
</body>
</html>