<html>
<head>
	<title>Page de test IWC</title>
</head>
<body>
    <script src="jquery.js"></script>
    <script src="script.js"></script>
    <style>
    .bloc_aide{
    	background-color: yellow;
    	padding:5px;
    }
    </style>
	<table border="1">
	<tr>
	<td>
	<form method="post" action="test.php">
		<div>
			<div id="cb">
				<input type="checkbox" id="test1" name="-a" checked/> <label for="test">Test 1</label> <button class="help" id="help1">?</button><br />
				<input type="checkbox" id="test2" name="-b" /> <label for="test">Test 2</label> <button class="help" id="help2">?</button><br />
				<input type="checkbox" id="test3" name="-c" disabled/> <label for="test">Test 3</label> <button class="help" id="help3">?</button><br />
				<input type="checkbox" id="test4" name="-d" /> <label for="test">Test 4</label> <button class="help" id="help4">?</button><br />
				<input type="checkbox" id="test5" name="-e" /> <label for="test">Test 5</label> <button class="help" id="help5">?</button><br />
			</div>
			<input type="radio" id="save" name="sad" value="save"/> <label for="save">Save</label> <input type="radio" id="restore" name="sad" value="restore"/> <label for="restore">Restore</label><button class="help" id="help6">?</button> <br />

			
			<label for="image_name">Nom de l'image:</label><input type="text" name="image_name" id="image_name"/><br />
		</div>
		<button id="bouton">Générer commande</button>
	</form>
	<div id="cmd" style="background-color:black;width:1000px;color:lime;padding:10px;font-family:'Courier new'">

	</div>
	<button style="color:red">Executer la commande</button>
	</td>
	<td>
		<div class="bloc_aide" id="b1">
		Voici de l'aide pour l'option 1.
		</div>
	</td>
	</tr>
	</table>
</body>
</html>