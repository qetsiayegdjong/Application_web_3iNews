#!/bin/bash


ls -la
 
exit 0