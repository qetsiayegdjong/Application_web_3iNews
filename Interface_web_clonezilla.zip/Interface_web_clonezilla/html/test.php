<html>
	<head>
		<title>Test</title>
	</head>
	<body style="background-color:black">
		<div style="margin:auto;border:1px solid lime;width:1000px;background-color:black;color:lime;font-family:'courier';">
			<p>
			<?php
			$commande = "ls -l";
			$output ="";
			if(isset($_POST['commande'])){
				$commande = $_POST['commande'];
			
				$commande = "sudo " . $commande . "";
				//sudo -u /bin/bash www-data commande
		        exec($commande ." 2>&1",$output,$returnvar);
		        //print_r($output);
		        foreach ($output as $ligne) {
		        	echo nl2br($ligne) . "<br />";
		        }
	        }

	        if(isset($_POST['bouton'])){
	        	$val = $_POST['bouton'];
	        	switch ($val) {
	        		case '1':
	        			exec("./creer.sh" ." 2>&1",$output,$returnvar);
	        			break;
        			case '2':
	        			exec("./supprimer.sh" ." 2>&1",$output,$returnvar);
	        			break;
        			case '3':
	        			exec("./lister.sh" ." 2>&1",$output,$returnvar);
	        			break;
	        		
	        		default:
	        			$output="Erreur de commande";
	        			break;
	        	}
	        	foreach ($output as $ligne) {
		        	echo nl2br($ligne) . "<br />";
		        }
	        }
	        ?>
			</p>
		</div>
		<div style="margin:auto">
			<center>
				<form action="test.php" method="post">
					<input style="width : 950px" type="text" name="commande" />
					<input type="button" value="Go" />
				</form>
			</center>
		</div>
		<div>
			<form action="test.php" method="POST">
				<button name="bouton" value="1">Créer répertoire test</button>
				<button name="bouton" value="2">Supprimer répertoire test</button>
				<button name="bouton" value="3">Afficher répertoire</button>
			</form>
		</div>
	</body>
</html>