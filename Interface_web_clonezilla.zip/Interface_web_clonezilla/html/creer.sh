#!/bin/bash


sudo mkdir test
 
exit 0