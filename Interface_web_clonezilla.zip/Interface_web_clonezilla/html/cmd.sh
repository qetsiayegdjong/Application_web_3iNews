#!/bin/bash


echo $($1)
 
exit 0