#!/bin/bash


sudo rmdir test
 
exit 0